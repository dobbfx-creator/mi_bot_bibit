Usá este 'diag' para ver exactamente qué valores está leyendo el core del settings.json (take_pct, relacion, at_R) y
en qué precio dispara. Ejecutá:
    cd C:\backtest_bibit_1to1\tests
    python run_scenarios.py --report
Luego compartí tests\report.json para ajustar la fórmula si fuese necesario.
